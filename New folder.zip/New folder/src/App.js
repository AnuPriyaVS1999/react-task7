import logo from './logo.svg';
import './App.css';
import NavBar from './components/includes/NavBar';


function App() {
  return(
  <NavBar />
  )
}

export default App;
